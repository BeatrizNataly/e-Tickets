package com.projeto.beatrizns.etickets.entities;

import java.io.Serializable;

public class Evento implements Serializable {
    private long id;
    private String nome;
    private String descricao;
    private String endereco;
    private String data;
    private String horario;
    private String duracao;
    private double valorEntrada;
    private double descontoMeia;
    private int classificacaoIndicativa; //quando 0 -> livre
    private int numeroIngressos;
    private int verified = 0; // 0 -> false; 1 -> true;

    public Evento(String nome, String descricao, String endereco, String data, String horario, String duracao,
                  double valorEntrada, double descontoMeia, int classificacaoIndicativa, int numeroIngressos, int verified) {
        this.nome = nome;
        this.descricao = descricao;
        this.endereco = endereco;
        this.data = data;
        this.horario = horario;
        this.duracao = duracao;
        this.valorEntrada = valorEntrada;
        this.descontoMeia = descontoMeia;
        this.classificacaoIndicativa = classificacaoIndicativa;
        this.numeroIngressos = numeroIngressos;
        this.verified = verified;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public double getValorEntrada() {
        return valorEntrada;
    }

    public void setValorEntrada(double valorEntrada) {
        this.valorEntrada = valorEntrada;
    }

    public double getDescontoMeia() {
        return descontoMeia;
    }

    public void setDescontoMeia(double descontoMeia) {
        this.descontoMeia = descontoMeia;
    }

    public int getClassificacaoIndicativa() {
        return classificacaoIndicativa;
    }

    public void setClassificacaoIndicativa(int classificacaoIndicativa) {
        this.classificacaoIndicativa = classificacaoIndicativa;
    }

    public int getNumeroIngressos() {
        return numeroIngressos;
    }

    public void setNumeroIngressos(int numeroIngressos) {
        this.numeroIngressos = numeroIngressos;
    }

    public boolean isVerified() {
        if(verified == 0)
            return false;
        return true;
    }

    public void setVerified(int verified) {
        this.verified = verified;
    }

    public double getValorMeiaEntrada(){
        return valorEntrada - (valorEntrada * descontoMeia);
    }

    public String getTextValorEntrada() {
        String valIngresso = "ENTRADA INTEIRA: R$" + getValorEntrada(); //check format currency
        if(getValorEntrada() == 0)
            valIngresso = "ENTRADA GRATUITA";
        else if(getDescontoMeia() != 0) {
            valIngresso += "\nENTRADA MEIA: R$" + getValorMeiaEntrada();
        }
        return valIngresso;
    }
}