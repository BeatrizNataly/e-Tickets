package com.projeto.beatrizns.etickets.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.adapter.ListaRecyclerViewAdapter;
import com.projeto.beatrizns.etickets.entities.Evento;
import com.projeto.beatrizns.etickets.strings.StringsListaExemplo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class NovosEventosFragment extends Fragment {
    private View vi;
    private RecyclerView lista;
    private List<Evento> eventosNovos;

    public NovosEventosFragment (){}

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        vi = inflater.inflate(R.layout.fragment_lista_de_eventos, container, false);
        setToolbarTitle();
        createStaticEventList();
        createRecyclerView();
        return vi;
    }

    private void setToolbarTitle() {
        TextView titulo = vi.findViewById(R.id.fragment_custom_title);
        titulo.setText("Novos eventos");
        ImageView icon = vi.findViewById(R.id.main_account_icon);
        icon.setBackgroundResource(R.drawable.ic_electric);
    }

    private void createStaticEventList() {
        eventosNovos = new ArrayList<>();
        eventosNovos.addAll(Arrays.asList(StringsListaExemplo.EVENTOS_NOVOS));
    }

    private void createRecyclerView() {
        ListaRecyclerViewAdapter adapter = new ListaRecyclerViewAdapter(eventosNovos);
        lista = vi.findViewById(R.id.lista_recyclerview_fragment);
        lista.setAdapter(adapter);
        lista.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        lista.setLayoutManager(linearLayoutManager);
    }
}
