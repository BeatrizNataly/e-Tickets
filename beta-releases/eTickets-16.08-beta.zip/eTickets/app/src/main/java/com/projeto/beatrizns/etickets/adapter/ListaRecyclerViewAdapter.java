package com.projeto.beatrizns.etickets.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.entities.Evento;
import com.projeto.beatrizns.etickets.ui.InformacoesDoEventoActivity;
import com.projeto.beatrizns.etickets.ui.MainActivity;

import java.util.ArrayList;
import java.util.List;

public class ListaRecyclerViewAdapter extends RecyclerView.Adapter<ListaRecyclerViewAdapter.Holder>{
    private List<Evento> eventos = new ArrayList<>();
    private static List<Evento> eventosCurtidos = new ArrayList<>();
    private Activity activity;

    // Construtor padrão
    public ListaRecyclerViewAdapter(Activity activity, List<Evento> eventos){
        this.activity = activity;
        this.eventos.addAll(eventos);
    }

    // Construtor placeholder de eventos curtidos
    public ListaRecyclerViewAdapter(Activity activity){
        this.activity = activity;
        this.eventos.addAll(eventosCurtidos);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.nomeEvento.setText(eventos.get(position).getNome());
        holder.local.setText(eventos.get(position).getEndereco());
        holder.dataHora.setText("Início: " + eventos.get(position).getData() + " - " + eventos.get(position).getHorario());
        holder.qtdIngressos.setText(eventos.get(position).getNumeroIngressos() + " ingressos");
        holder.qtdCurtidas.setText("1.2k favoritos"); //futuramente pegará dados de um BD e terá números muito grandes formatados.

        if(!eventos.get(position).isVerified())
            holder.verified.setVisibility(View.GONE);

        holder.container.setOnClickListener(view -> {
            Intent intent = new Intent(activity, InformacoesDoEventoActivity.class);
            intent.putExtra("EVENTO", eventos.get(position));
            activity.startActivity(intent);
        });

        holder.liked.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if(!eventosCurtidos.contains(eventos.get(position)))
                eventosCurtidos.add(eventos.get(position));
            } else {
                if(eventosCurtidos.contains(eventos.get(position)))
                eventosCurtidos.remove(eventos.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventos.size();
    }

    public class Holder extends RecyclerView.ViewHolder{
        TextView nomeEvento, local, dataHora, qtdIngressos, qtdCurtidas;
        ImageView verified, container;
        ToggleButton liked;
        public Holder(@NonNull View itemView) {
            super(itemView);
            findViewsById(itemView);
        }

        private void findViewsById(@NonNull View itemView) {
            nomeEvento = itemView.findViewById(R.id.item_title);
            local = itemView.findViewById(R.id.item_endereco);
            dataHora = itemView.findViewById(R.id.item_data_hora);
            qtdIngressos = itemView.findViewById(R.id.item_numero_ingressos);
            qtdCurtidas = itemView.findViewById(R.id.item_favoritos);
            verified = itemView.findViewById(R.id.item_verified);
            container = itemView.findViewById(R.id.item_container);
            liked = itemView.findViewById(R.id.item_ic_favorito);
        }
    }

    /*
    por hora a quantidade de likes será apenas demonstrativa, mostrada por um número aleatório;
    no futuro será uma table relacionada com o id do evento e uma relação incremental ou decremental
    dos likes.
     */
}
