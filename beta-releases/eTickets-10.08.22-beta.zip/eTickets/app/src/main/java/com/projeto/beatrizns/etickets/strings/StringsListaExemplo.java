package com.projeto.beatrizns.etickets.strings;

import com.projeto.beatrizns.etickets.entities.Evento;

public class StringsListaExemplo {

    private static final String DESCRICAO_PLACEHOLDER = "Lorem ipsum dolor sit amet, consectetur adipiscing elit." +
            " Ut vitae neque eu purus vestibulum finibus. In congue varius massa, in consectetur leo rutrum finibus." +
            " Suspendisse luctus gravida hendrerit. Vestibulum porta feugiat leo, et venenatis neque fringilla vitae. Aliquam molestie a velit vitae congue.";

    public static final Evento EVENTO_1 = new Evento("Festival do Morango", DESCRICAO_PLACEHOLDER, "Parque da Água Branca, São Paulo - SP",
            "05/08", "10:00", "até às 18hrs", 0, 0.0, 0, 200, 0);

    public static final Evento EVENTO_2 = new Evento("LOLLAPALOOZA 2022 - ABERTURA", DESCRICAO_PLACEHOLDER, "Barra da Tijuca, Rio de Janeiro - RJ",
            "10/01/2023", "19:45", "4 horas", 85, 0.45, 14, 1230, 1);

    public static final Evento EVENTO_3 = new Evento("SÃO PAULO X PALMEIRAS - MORUMBI", DESCRICAO_PLACEHOLDER, "Estádio Morumbi, São Paulo, Morumbi - SP",
            "12/08", "16:30", "1h30min", 120, 0.5, 12, 2500, 1);

    public static final Evento EVENTO_4 = new Evento("festa junina beneficiente", DESCRICAO_PLACEHOLDER, "Rua dos Camargos, Centro, Arceburgo - MG",
            "20/06", "15:00", "5 horas", 15.70, 0, 0, 500, 0);

    public static final Evento EVENTO_5 = new Evento("Encontro de fãs DC Comics - Santos", DESCRICAO_PLACEHOLDER, "Praça de eventos central, Santos - SP",
            "31/08", "12:00", "2 horas", 0, 0, 14, 100, 0);

    public static final Evento EVENTO_6 = new Evento("DANÇA DAS 3 FRONTEIRAS", DESCRICAO_PLACEHOLDER, "Marco das Três Fronteiras, Nova Iguaçu - SC",
            "06/08", "18:00", "2 horas", 50.00, 0.5, 0, 335, 1);

    public static final Evento[] EVENTOS_EM_ALTA = {EVENTO_1, EVENTO_2, EVENTO_3, EVENTO_4};
    public static final Evento[] EVENTOS_NOVOS = {EVENTO_4, EVENTO_5, EVENTO_6, EVENTO_3};
    public static final Evento[] EVENTOS_FAVORITOS = {EVENTO_3, EVENTO_5, EVENTO_1};
    public static final Evento[] MEUS_EVENTOS = {EVENTO_1, EVENTO_5, EVENTO_4};
}
