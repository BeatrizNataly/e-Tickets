package com.projeto.beatrizns.etickets.ui;

import static com.projeto.beatrizns.etickets.strings.Constantes.EM_ALTA;
import static com.projeto.beatrizns.etickets.strings.Constantes.EM_ALTA_FRAG;
import static com.projeto.beatrizns.etickets.strings.Constantes.FAVORITOS;
import static com.projeto.beatrizns.etickets.strings.Constantes.FAVORITOS_FRAG;
import static com.projeto.beatrizns.etickets.strings.Constantes.MEUS_EVENTOS;
import static com.projeto.beatrizns.etickets.strings.Constantes.MEUS_EVENTOS_FRAG;
import static com.projeto.beatrizns.etickets.strings.Constantes.NOVOS_EVENTOS;
import static com.projeto.beatrizns.etickets.strings.Constantes.NOVOS_EVENTOS_FRAG;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.projeto.beatrizns.etickets.R;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "LOGI ECCHO ->";
    private String[] title = {EM_ALTA, NOVOS_EVENTOS, FAVORITOS, MEUS_EVENTOS};
    private int[] icons = {R.drawable.ic_fire, R.drawable.ic_electric, R.drawable.ic_favorite, R.drawable.ic_ticket};

    private MaterialToolbar toolbar;
    private TextView titulo;
    private ImageView iconePrincipal, iconeCarrinho, iconeConta;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setToolBar();
        setBottomNavigation();
    }

    private void setBottomNavigation() {
        titulo.setText(title[0]);
        iconePrincipal.setBackgroundResource(icons[0]);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
        NavController navController = navHostFragment.getNavController();
        setBottomNavListener(navController);
        //  NavigationUI.setupWithNavController(bottomNavigationView, navController); //Este método não funciona junto do setOnItemSelectedListener.
        // Em suma, não há como controlar a navegação e a interface ao mesmo tempo com os dois métodos, é necessário abrir mão de um para usar o outro.
    }

    private void setBottomNavListener(NavController navController) {
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case NOVOS_EVENTOS_FRAG:
                    titulo.setText(title[1]);
                    iconePrincipal.setBackgroundResource(icons[1]);
                    navController.navigate(NOVOS_EVENTOS_FRAG);
                    break;
                case FAVORITOS_FRAG:
                    titulo.setText(title[2]);
                    iconePrincipal.setBackgroundResource(icons[2]);
                    navController.navigate(FAVORITOS_FRAG);
                    break;
                case MEUS_EVENTOS_FRAG:
                    titulo.setText(title[3]);
                    iconePrincipal.setBackgroundResource(icons[3]);
                    navController.navigate(MEUS_EVENTOS_FRAG);
                    break;
                default: // default -> EmAltaFragment
                    titulo.setText(title[0]);
                    iconePrincipal.setBackgroundResource(icons[0]);
                    navController.navigate(EM_ALTA_FRAG);
            }
            return true;
        });
    }

    private void setToolBar() {
        titulo = findViewById(R.id.fragment_custom_title);
        iconePrincipal = findViewById(R.id.main_page_icon);
        toolbar = findViewById(R.id.topAppBar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.top_app_bar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) { // Verificar funcionamento
        if (item.getItemId() == R.id.item_account)
            Log.i(TAG, "onOptionsItemSelected: ACESSAR CONTA");
        else if (item.getItemId() == R.id.item_cart)
            Log.i(TAG, "onOptionsItemSelected: ACESSAR CARRINHO");
        return super.onOptionsItemSelected(item);
    }
}