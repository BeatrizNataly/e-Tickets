package com.projeto.beatrizns.etickets.strings;

import com.projeto.beatrizns.etickets.R;

public class Constantes {
    // TITULOS
    public static final String EM_ALTA = "Em alta";
    public static final String NOVOS_EVENTOS = "Novos eventos";
    public static final String FAVORITOS = "Favoritos";
    public static final String MEUS_EVENTOS = "Meus eventos";

    // IDs
    public static final int MEUS_EVENTOS_FRAG = R.id.meusIngressosFragment ;
    public static final int EM_ALTA_FRAG = R.id.emAltaFragment;
    public static final int NOVOS_EVENTOS_FRAG = R.id.novosEventosFragment;
    public static final int FAVORITOS_FRAG = R.id.favoritosFragment;
}
