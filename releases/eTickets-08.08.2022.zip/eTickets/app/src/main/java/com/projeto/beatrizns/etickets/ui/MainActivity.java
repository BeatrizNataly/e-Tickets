package com.projeto.beatrizns.etickets.ui;

import android.os.Bundle;
import android.util.Log;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.ui.fragment.EmAltaFragment;
import com.projeto.beatrizns.etickets.ui.fragment.FavoritosFragment;
import com.projeto.beatrizns.etickets.ui.fragment.MeusIngressosFragment;
import com.projeto.beatrizns.etickets.ui.fragment.NovosEventosFragment;

public class MainActivity extends AppCompatActivity {

    // Fragment with bnv -> https://www.youtube.com/watch?v=Chso6xrJ6aU

    private BottomNavigationView bottomNavigationView;
    private FrameLayout container;
    private Fragment[] fragmentos = {new EmAltaFragment(), new NovosEventosFragment(),
    new FavoritosFragment(), new MeusIngressosFragment()};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setBottomNavigation();
    }

    private void setBottomNavigation() {
        container = findViewById(R.id.bottomnav_fragment_container);
        getSupportFragmentManager().beginTransaction().replace(R.id.bottomnav_fragment_container, fragmentos[0]).commit(); //inicializa por padrão no 1° fragmento
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = fragmentos[0]; //Por padrão é o 1° fragmento, mas pode alternar entre os demais.
            switch(item.getItemId()){
                case R.id.page_1_alta:
                    selectedFragment = fragmentos[0];
                    break;
                case R.id.page_2_novos:
                    selectedFragment = fragmentos[1];
                    break;
                case R.id.page_3_favoritos:
                    selectedFragment = fragmentos[2];
                    break;
                case R.id.page_4_meus_tickets:
                    selectedFragment = fragmentos[3];
                    break;
                default:
                    Toast.makeText(this, "Ocorreu um erro inesperado", Toast.LENGTH_SHORT).show();
                    Log.i("BOTTOM TAB ERRO", "setBottomNavigation: Id da página ou classe do fragment não encontrado.");
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.bottomnav_fragment_container, selectedFragment).commit();
            return true;
        });
    }

}