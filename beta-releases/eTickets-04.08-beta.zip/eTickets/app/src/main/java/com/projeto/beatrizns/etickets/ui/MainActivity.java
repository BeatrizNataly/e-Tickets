package com.projeto.beatrizns.etickets.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.tabs.TabLayoutMediator;
import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.adapter.PageAdapter;

public class MainActivity extends AppCompatActivity {
//O fragment lista de eventos pode ser reutilizado para as 4 tabs do aplicativo.
    // https://material.io/components/bottom-navigation/android#bottom-navigation-bar

    private BottomNavigationView bottomNavigationView;
    private PageAdapter pageAdapter;
    private ViewPager2 viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setPager();
        setBottomNavigation();
    }

    private void setPager() {
        pageAdapter = new PageAdapter(getSupportFragmentManager(), getLifecycle());
        pageAdapter.adicionaFragmento(new EmAltaFragment(), "Em alta");
        viewPager = findViewById(R.id.main_view_pager);
        viewPager.setAdapter(pageAdapter);
    }

    private void setBottomNavigation() {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch(item.getItemId()){
                case R.id.page_1_alta:
                    getSupportFragmentManager().beginTransaction().replace(R.id.main_view_pager, pageAdapter.getFragment(0)).commit();
                    break;
                    //insere demais fragments lançados conforme vierem a surgir
                default:
                    Toast.makeText(this, "Ocorreu um erro inesperado", Toast.LENGTH_SHORT).show();
                    Log.i("BOTTOM TAB ERRO", "setBottomNavigation: Id da página ou classe do fragment não encontrado.");
            }
            return true;
        });
    }

}