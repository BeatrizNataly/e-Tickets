package com.projeto.beatrizns.etickets.ui;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.adapter.ListaRecyclerViewAdapter;
import com.projeto.beatrizns.etickets.entities.Evento;

public class InformacoesDoEventoActivity extends AppCompatActivity {
    private TextView nomeEvento, enderecoEvento, dataHoraEvento,
            numIngressos, valorIngressos, classificacao, descricaoEvento, eventoFinalizado;
    private ImageView verified, bannerEvento, arrowBackBtn, accountBtn;
    private Button comprarBtn;
    private Toolbar toolbar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_evento);
        findViews();
        setToolbarListeners();
        getInformacoesDoEvento();
    }

    private void setToolbarListeners() {
        arrowBackBtn.setOnClickListener(view -> { finish(); });
        // <-- insert account listener -->
        accountBtn.setOnClickListener(view -> {
            Toast.makeText(this, "Acessando conta...", Toast.LENGTH_SHORT).show();
        });
    }

    private void findViews() {
        nomeEvento = findViewById(R.id.info_nome_evento);
        enderecoEvento = findViewById(R.id.item_endereco);
        dataHoraEvento = findViewById(R.id.item_data_hora);
        numIngressos = findViewById(R.id.item_numero_ingressos);
        valorIngressos = findViewById(R.id.item_valor_ingressos);
        classificacao = findViewById(R.id.item_classificacao);
        descricaoEvento = findViewById(R.id.info_descricao);
        eventoFinalizado = findViewById(R.id.textview_evento_inativo);
        eventoFinalizado.setVisibility(View.GONE);

        verified = findViewById(R.id.info_item_verified);
        bannerEvento = findViewById(R.id.imageView);
        arrowBackBtn = findViewById(R.id.info_arrow_back);
        accountBtn = findViewById(R.id.info_account_icon);

        comprarBtn = findViewById(R.id.button_comprar_ingressos);
        comprarBtn.setClickable(true);
    }

    private void getInformacoesDoEvento() {
        if(getIntent().getSerializableExtra("EVENTO") != null){
            Evento evento = (Evento) getIntent().getSerializableExtra("EVENTO");
            nomeEvento.setText(evento.getNome().toUpperCase());
            enderecoEvento.setText(evento.getEndereco());
            dataHoraEvento.setText("Início: " + evento.getData() + " - " + evento.getHorario());
            numIngressos.setText(evento.getNumeroIngressos() + " INGRESSOS DISPONÍVEIS");
            descricaoEvento.setText(evento.getDescricao());
            getTextValorIngresso(evento);
            getTextClassificacaoIndicativa(evento);
            if(!evento.isVerified())
                verified.setVisibility(View.INVISIBLE);
            if(!evento.isEventoAtivo())
                unableBtnComprarIngressos();
        }
    }

    private void unableBtnComprarIngressos() {
        comprarBtn.setClickable(false);
        comprarBtn.setBackgroundColor(Color.GRAY);
        eventoFinalizado.setVisibility(View.VISIBLE);
    }

    private void getTextClassificacaoIndicativa(Evento evento) {
        if(evento.getClassificacaoIndicativa() == 0) //check age restriction vinculed to account
        classificacao.setText("CLASSIFICAÇÃO INDICATIVA: LIVRE PARA TODOS OS PÚBLICOS");
        else
            classificacao.setText("CLASSIFICAÇÃO INDICATIVA: " + evento.getClassificacaoIndicativa() + " ANOS");
    }

    private void getTextValorIngresso(Evento evento) {
        String valIngresso = evento.getTextValorEntrada();
        valorIngressos.setText(valIngresso);
    }
}
