package com.projeto.beatrizns.etickets.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.projeto.beatrizns.etickets.R;
import com.projeto.beatrizns.etickets.entities.Evento;

import java.util.ArrayList;
import java.util.List;

public class ListaRecyclerViewAdapter extends RecyclerView.Adapter<ListaRecyclerViewAdapter.Holder>{
    private List<Evento> eventos = new ArrayList<>();

    public ListaRecyclerViewAdapter(List<Evento> eventos){
        this.eventos.addAll(eventos);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista, parent, false);
        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.nomeEvento.setText(eventos.get(position).getNome());
        holder.local.setText(eventos.get(position).getEndereco());
        holder.dataHora.setText("Início: " + eventos.get(position).getData() + " - " + eventos.get(position).getHorario());
        holder.qtdIngressos.setText(eventos.get(position).getNumeroIngressos() + " ingressos");
        holder.qtdCurtidas.setText("1.2k favoritos"); //futuramente pegará dados de um BD e terá números muito grandes formatados.

        if(!eventos.get(position).isVerified())
            holder.verified.setVisibility(View.GONE);
    }

    @Override
    public int getItemCount() {
        return eventos.size();
    }

    public class Holder extends RecyclerView.ViewHolder{
        TextView nomeEvento, local, dataHora, qtdIngressos, qtdCurtidas;
        ImageView verified, liked;
        public Holder(@NonNull View itemView) {
            super(itemView);
            findViewsById(itemView);
        }

        private void findViewsById(@NonNull View itemView) {
            nomeEvento = itemView.findViewById(R.id.item_title);
            local = itemView.findViewById(R.id.item_endereco);
            dataHora = itemView.findViewById(R.id.item_data_hora);
            qtdIngressos = itemView.findViewById(R.id.item_numero_ingressos);
            qtdCurtidas = itemView.findViewById(R.id.item_favoritos);
            verified = itemView.findViewById(R.id.item_verified);
            liked = itemView.findViewById(R.id.item_ic_favorito);
        }
    }

    /*
    por hora a quantidade de likes será apenas demonstrativa, mostrada por um número aleatório;
    no futuro será uma table relacionada com o id do evento e uma relação incremental ou decremental
    dos likes.
     */
}
